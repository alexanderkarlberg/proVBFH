c        -*- Fortran -*-
      character * 3 storelabel
      common/cstorelabel/storelabel
