c -*- Fortran -*-

c store the V*V*->HH leptonic tensor

      double complex vvhh(0:3,0:3,2,2)
      double complex vvhh_re(0:3,0:3,4,2)

      common /vvhhleptens/ vvhh, vvhh_re

