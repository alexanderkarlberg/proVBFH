c -*- Fortran -*-
      real * 8 em_alpha,em_muren2
      common/pwhg_em/em_alpha,em_muren2
      save /pwhg_em/
