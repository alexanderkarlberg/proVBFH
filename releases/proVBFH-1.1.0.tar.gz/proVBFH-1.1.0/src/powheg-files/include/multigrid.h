c -*- Fortran -*-
      integer flg_multigrid
      common/pwhg_multigrid/ flg_multigrid
      save /pwhg_multigrid/
