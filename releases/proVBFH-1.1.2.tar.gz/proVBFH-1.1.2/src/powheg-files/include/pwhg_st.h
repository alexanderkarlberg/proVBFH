c -*- Fortran -*-
      real * 8 st_alpha,st_mufact2,st_muren2,st_lambda5MSB,
     #st_facfact,st_renfact
      real * 8 st_mufactA2,st_mufactB2
      integer st_nlight,st_bornorder
      common/pwhg_st/st_alpha,st_mufact2,st_muren2,
     # st_lambda5MSB, st_facfact,st_renfact,st_mufactA2,st_mufactB2,
c integer
     # st_nlight,st_bornorder
      save /pwhg_st/
