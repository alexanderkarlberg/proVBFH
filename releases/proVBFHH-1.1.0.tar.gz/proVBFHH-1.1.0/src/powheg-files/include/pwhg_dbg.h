c -*- Fortran -*-

      logical dbg_softtest,dbg_colltest
      common/pwhg_dbg/dbg_softtest,dbg_colltest
      save /pwhg_dbg/
