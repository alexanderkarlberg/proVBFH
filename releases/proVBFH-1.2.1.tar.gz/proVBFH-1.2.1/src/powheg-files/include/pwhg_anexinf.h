c -*- fortran -*- 
      real * 8 anexinf_sigarr(maxalr)
      character * 12 anexinf_type
      integer anexinf_narr
      common/pwhg_anexinf/anexinf_narr,anexinf_type,anexinf_sigarr
