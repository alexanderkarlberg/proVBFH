c -*- Fortran -*-
      real * 8 physpar_ml(3)
      real * 8 physpar_mq(6)
      common/pwhg_physpar/physpar_ml,physpar_mq
      save /pwhg_physpar/
