c -*- Fortran -*-
      real * 8 st_alpha,st_mufact2,st_muren2,st_lambda5MSB,
     #         st_facfact,st_renfact
      integer st_nlight,st_bornorder
      common/pwhg_st/st_alpha,st_mufact2,st_muren2,
     # st_lambda5MSB, st_facfact,st_renfact,
c integer
     # st_nlight,st_bornorder
      save /pwhg_st/
